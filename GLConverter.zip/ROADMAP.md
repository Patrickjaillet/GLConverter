# GLConverter — Roadmap

**GLConverter**
Copyright © 2026 Patrick JAILLET — All rights reserved
Email: contact.shaderstudio@gmail.com
Website: https://patrickjaillet.github.io/sandefjord-software

---

## Stack technique

- TypeScript
- Rust (compilé en WebAssembly pour le moteur de golfing/parsing haute performance)
- JavaScript
- Three.js
- Vite (build 100% statique, compatible GitHub Pages)

---

## Development Conventions

- [ ] Strictely General language only English
- [ ] Theme White only
- [ ] Source language entirely in English (variable names, functions, classes)
- [ ] Strictely No comments in the source code
- [ ] Strictely Every added feature must be reflected in this ROADMAP.md
- [ ] Automatic software version serialization SemVer strict
- [ ] Every modification must be reflected for the end-user in the CHANGELOG.md
- [ ] The README.md must be created and updated for the end-user and include a software screenshot in docs/screenshot.png
- [ ] Systematic synchronization (commit+push+Pages) with the [https://github.com/Patrickjaillet/GLConverter](https://github.com/Patrickjaillet/GLConverter) repository upon every project modification
- [ ] Add on github in repository details, Description, Website, Topics : sandefjord-software.
- [ ] Do not add the name of Phases but just the number of version
- [ ] Do not add ROADMAP.md to github
- [ ] Never integrate Claude AI into GitHub, the files, or the GitHub contributors list
- [ ] Creation of all files and documents required for the GitHub repository
- [ ] Integrate copyright / Email / Website information

---

## v0.1.0

- [x] Initialisation du repository GitHub (`GLConverter`) *(structure locale prête, push à effectuer)*
- [x] Setup projet Vite + TypeScript strict mode
- [x] Configuration `base` Vite pour compatibilité GitHub Pages (chemins relatifs)
- [x] Setup Rust + wasm-pack pour le futur moteur WASM *(squelette Cargo, build wasm-pack non exécuté)*
- [x] Structure de dossiers (`src/`, `src/core/`, `src/ui/`, `src/wasm/`, `docs/`)
- [x] Intégration Three.js (canvas de fond / éléments visuels de l'interface)
- [x] Fichier `LICENSE` avec mention du copyright
- [x] Fichier `README.md` initial
- [x] Fichier `CHANGELOG.md` initial
- [x] Fichier `package.json` avec version SemVer `0.1.0`
- [x] Workflow GitHub Actions pour déploiement automatique sur GitHub Pages

## v0.2.0

- [x] Intégration de l'éditeur de code (Monaco Editor ou CodeMirror 6) *(CodeMirror 6)*
- [x] Vue double panneau : code original (gauche) / code converti (droite)
- [x] Thème blanc unique appliqué à l'éditeur
- [x] Synchronisation automatique en temps réel entre les deux panneaux *(mode identité, la logique de golfing arrive en v0.3.0)*
- [x] Détection automatique du langage source (JavaScript en priorité)
- [x] Système de tokenisation/parsing du code source (AST) *(via Acorn)*

## v0.3.0

- [x] Moteur de minification (suppression espaces, points-virgules, sauts de ligne)
- [x] Moteur de renommage de variables (identifiants courts a, b, c...)
- [x] Moteur de simplification d'opérateurs (raccourcis logiques/arithmétiques)
- [x] Détection et fusion des déclarations de variables
- [x] Suppression du code mort et des expressions redondantes
- [x] Bouton toggle "Minified / Justified"
- [x] Mode "Justified" : reformattage lisible avec indentation propre

## v0.4.0

- [x] Moteur de golfing avancé (remplacement de boucles par équivalents plus courts)
- [x] Optimisation des expressions ternaires et raccourcis conditionnels
- [x] Optimisation des appels de fonctions natives (raccourcis connus de golfing JS)
- [x] Système de règles de golfing configurables (activer/désactiver des techniques)
- [x] Calcul et affichage du nombre de caractères (avant / après)
- [x] Score de compression en pourcentage

## v0.5.0

- [x] Conversion inverse : code golfé → code structuré (dé-golfing)
- [x] Restauration de noms de variables lisibles
- [x] Restauration de l'indentation et de la structure de blocs
- [x] Détection heuristique des patterns golfés courants pour reconstruction
- [x] Validation de l'équivalence fonctionnelle entre original et converti

## v0.6.0

- [ ] Intégration du moteur Rust/WASM pour le parsing et le golfing haute performance
- [ ] Bascule transparente entre moteur JS et moteur WASM
- [ ] Benchmark de performance intégré à l'interface

## v0.7.0

- [ ] Import de fichier local (drag & drop)
- [ ] Export du code converti (.js, .txt)
- [ ] Copie rapide dans le presse-papiers
- [ ] Historique local des conversions (session courante)
- [ ] Undo / Redo dans l'éditeur

## v0.8.0

- [ ] Interface utilisateur finalisée en thème blanc strict
- [ ] Responsive design (desktop / tablette)
- [ ] Éléments visuels Three.js intégrés à l'UI (arrière-plan ou transitions)
- [ ] Accessibilité clavier (raccourcis pour toggle et conversion)

## v0.9.0

- [ ] Tests unitaires du moteur de golfing
- [ ] Tests unitaires du moteur de dé-golfing
- [ ] Tests d'intégration de l'interface
- [ ] Vérification complète de la compatibilité GitHub Pages
- [ ] Optimisation du bundle final (taille, lazy loading)

## v1.0.0

- [ ] Capture d'écran officielle du logiciel dans `docs/screenshot.png`
- [ ] `README.md` finalisé avec captures, instructions d'usage et description
- [ ] `CHANGELOG.md` complet et à jour
- [ ] Description, Website et Topics (`sandefjord-software`) configurés sur GitHub
- [ ] Déploiement final validé sur GitHub Pages
- [ ] Tag de version `v1.0.0` publié sur le repository
